from brain_games.cli import welcome_user


ROUND_COUNT = 3


def game_engine(description, game_func):
    name = welcome_user()
    print(description)
    for _ in range(ROUND_COUNT):
        correct, correct_answer, user_answer = game_func()
        if correct:
            print("Correct!")
        else:
            print(f"'{user_answer}' is an incorrect answer, {name}! "
                  f"The correct answer was '{correct_answer}'."
                  f" Let's try again, {name}!")
            break
    else:
        print(f"Congratulations, {name}!")
