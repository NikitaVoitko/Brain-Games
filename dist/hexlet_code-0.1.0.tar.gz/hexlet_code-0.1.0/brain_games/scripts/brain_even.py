#!/usr/bin/env python3
def main():

    # import game1
    from brain_games.game1 import is_even
    is_even()


if __name__ == '__main__':
    main()
