#!/usr/bin/env python3
def main():

    # import game_runner and choose is_even as the game
    from brain_games.engine.game_runner import game_runner
    game_runner("gcd_game")


if __name__ == '__main__':
    main()
